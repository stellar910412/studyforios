//
//  AppDelegate.h
//  APSocialSDKDemo
//
//  Created by Alipay on 15/6/24.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

